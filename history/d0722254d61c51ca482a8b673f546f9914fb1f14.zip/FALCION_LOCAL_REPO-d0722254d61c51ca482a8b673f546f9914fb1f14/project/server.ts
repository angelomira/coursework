import express,
{
    Request,
    Response,
} from 'express';

import * as bodyparser from 'body-parser';

import API from './api/currencies';

import Currency from './models/currency';
import Loggerin from './addons/loggerin';

import cors from 'cors';

const PORT: number = 3000;

const app = express();
const api = new API();

const PARSEC = bodyparser.json();

app.use(express.json());
app.use(cors());

app.get('/api/currencies/:date', async (
    req: Request,
    res: Response
) => {
    Loggerin.info('Caught GET currencies info API request at', req.params.date);

    try {
        const date: string = req.params.date;

        if (!date) {
            return res.status(400).json({
                error: 'Currency date is missing in the request header.'
            }).send();
        }

        const currencies: Currency[] = await api.currencies(date);

        if (currencies.length == 0) {
            return res.status(400).json({
                error: 'Currencies data not found.'
            }).send();
        }

        const data: object[] = currencies.map(curr => curr.toJSON());

        if (data.length == 0) {
            return res.status(400).json({
                error: 'Currencies data not found.'
            }).send();
        }

        res.send(data);
    } catch (error) {
        Loggerin.error('Error fetcing currencies: ', error);

        return res.status(500).json({
            error: 'Internal server error.'
        }).send();
    }
});

app.get('/api/currencies/:date/:curr', async (
    req: Request,
    res: Response
) => {
    Loggerin.info('Caught GET currency info API request about:', req.params.curr, 'at', req.params.date);

    try {
        const code: string = req.params.curr;
        const date: string = req.params.date;

        if (!code) {
            return res.status(400).json({
                error: 'Currency code is missing in the request header.'
            }).send();
        }

        if (!date) {
            return res.status(400).json({
                error: 'Currency date is missing in the request header.'
            }).send();
        }

        const currency = await api.currency(code, date);

        if (!currency) {
            return res.status(404).json({
                error: 'Currency data not found.'
            }).send();
        }

        res.send(currency);
    } catch (error) {
        Loggerin.error('Error fetcing currency: ', error);

        return res.status(500).json({
            error: 'Internal server error.'
        }).send();
    }
});

import fs from 'fs-extra';

app.post('/api/registry/', PARSEC, async (
    req: Request,
    res: Response
) => {
    Loggerin.info('Caught POST registry API request.');

    /*! THIS IS A TEST-MODE IMITATION OF DATABASE. */
    try {
        if (!req.body) {
            return res.status(400).json({
                error: 'No body to registry or parse in request.'
            });
        }

        const { username, password, other } = req.body;

        const data: object = {
            username,
            password,
            other,
        };

        await fs.writeFile('data.json', JSON.stringify(data, undefined, 2));

        res.status(200).json({
            message: 'Successfully registered user.'
        }).send();
    } catch (error) {
        Loggerin.error('Error fetcing POST of user registry: ', error);

        return res.status(500).json({
            error: 'Internal server error.'
        }).send();
    }
});

app.post('/api/auth/', PARSEC, async (
    req: Request,
    res: Response
) => {
    Loggerin.info('Caught POST authorization API request.');

    /*! THIS IS A TEST-MODE IMITATION OF DATABASE. */
    try {
        if (!req.body) {
            return res.status(400).json({
                error: 'No body to registry or parse in request.'
            });
        }

        const { username, password, other } = req.body;

        const database = JSON.parse((await fs.readFile('data.json')).toString());

        if(
            database['username'] == username &&
            database['password'] == password
        ) {
            return res.status(200).json({
                message: 'Login success.'
            }).send();
        }

    } catch(error) {
        Loggerin.error('Error fetcing POST of user auth: ', error);

        return res.status(500).json({
            error: 'Internal server error.'
        }).send();
    }
});

app.listen(PORT | 3000, () => {
    Loggerin.info('Server is running on port: ', PORT);
});

const BASE_URL = 'http://localhost:3000/';

var DEF_DATE = new Date();

document.addEventListener('DOMContentLoaded', async () => {
    const SELECT_CURR1 = document.getElementById('select.curr1');
    const SELECT_CURR2 = document.getElementById('select.curr2');

    const INPUT_DATE = document.getElementById('input.date');

    INPUT_DATE.value = __convert_datetime('inputbx');

    try {
        var response;

        if(!INPUT_DATE) {
            response = await fetch(BASE_URL + `api/currencies/${__convert_datetime('request')}`, 
            {
                method: 
                    'GET',
                mode: 
                    'cors',
                headers: {
                    'Content-Type': 'application/json',
                },
            });
        } else {
            response = await fetch(BASE_URL + `api/currencies/${__convert_datetime('request', INPUT_DATE.value)}`, 
            {
                method: 
                    'GET',
                mode: 
                    'cors',
                headers: {
                    'Content-Type': 'application/json',
                },
            });
        }

        if (!response.ok) {
            throw new Error('Error retrieving data from API.');
        }

        const currencies = await response.json();

        for(const curr of currencies) {
            const item = document.createElement('option');

            item.text
                = curr['symb_code'];
            item.value 
                = curr['symb_code'];
            SELECT_CURR1?.add(item);
        }

        for(const curr of currencies) {
            const item = document.createElement('option');

            item.text
                = curr['symb_code'];
            item.value 
                = curr['symb_code'];
            SELECT_CURR2?.add(item);
        }

        SELECT_CURR1.value = 'RUB';
        SELECT_CURR2.value = 'USD';

        CURRENCIES_REGISTRY= currencies;
    } catch (error) {
        console.error('Error via requesting data from API:', error.message);
    }

    const INPUT_CURR1 = document.getElementById('input.curr1');
    const INPUT_CURR2 = document.getElementById('input.curr2');

    INPUT_CURR1.addEventListener('input', (event) => __inputcurr1_inputevent(event));
    INPUT_CURR1.value = 0;
    INPUT_CURR2.addEventListener('input', (event) => __inputcurr2_inputevent(event));
    INPUT_CURR2.value = 0;

    SELECT_CURR1.addEventListener('change', (event) => __selectcurr1_inputevent(event));
    SELECT_CURR2.addEventListener('change', (event) => __selectcurr2_inputevent(event));

    document.getElementById('button.curr').addEventListener('click', () => {
        var s_value = 
        SELECT_CURR1.value;
        
        SELECT_CURR1.value = SELECT_CURR2.value;
        SELECT_CURR2.value = s_value;

        var i_value = 
        INPUT_CURR1.value;

        INPUT_CURR1.value = INPUT_CURR2.value;
        INPUT_CURR2.value = i_value;
    });

    INPUT_DATE.addEventListener('change', (event) => __innerupdate(1));
});

function __inputcurr1_inputevent(event) {
    __innerupdate(1);
}

function __inputcurr2_inputevent(event) {
    __innerupdate(2);
}

function __selectcurr1_inputevent(event) {
    __innerupdate(1);
}

function __selectcurr2_inputevent(event) {
    __innerupdate(1);
}

async function __innerupdate(reason) {
    const INPUT_CURR1 = document.getElementById('input.curr1');
    const INPUT_CURR2 = document.getElementById('input.curr2');
    const INPUT_DATE = document.getElementById('input.date');
    const SELECT_CURR1 = document.getElementById('select.curr1');
    const SELECT_CURR2 = document.getElementById('select.curr2');

    try {
        const response = await fetch(BASE_URL + `api/currencies/${__convert_datetime('request', INPUT_DATE.value)}`, 
        {
            method: 
                'GET',
            mode: 
                'cors',
            headers: {
                'Content-Type': 'application/json',
            },
        });

        console.log(`api/currencies/${__convert_datetime('request', INPUT_DATE.value)}`);

        if (!response.ok) {
            throw new Error('Error retrieving data from API.');
        }

        const currencies = await response.json();

        console.log(currencies);

        const curr1 = currencies.find(curr => curr['symb_code'] == SELECT_CURR1.value);
        const curr2 = currencies.find(curr => curr['symb_code'] == SELECT_CURR2.value);

        const RUB = currencies.find(curr => curr['symb_code'] == 'RUB');

        if(reason == 1) {
            INPUT_CURR2.value = __convert_currencies(curr1, curr2, RUB, Number(INPUT_CURR1.value));
        } else if(reason == 2) {
            INPUT_CURR1.value = __convert_currencies(curr2, curr1, RUB, Number(INPUT_CURR2.value));
        }
    } catch(error) {
        console.error('Error via requesting data from API:', error.message);
    }
}

function __convert_currencies(curr1, curr2, RUB, amount) {
    const amount_rub = amount * curr1['ratio'] / curr1['amount'];
    const amount_res = amount_rub * RUB['amount'] / RUB['ratio'];

    return amount_res * curr2['amount'] / curr2['ratio'];
}


function __convert_datetime(target, value = undefined) {
    function digitize(item) {
        if(item.length == 2)
            return item;
        else if(item.length == 1)
            return '0' + item;
        else
            return '0';
    }

    var date;

    if(!value)
        date = new Date().toLocaleDateString().split('/');
    else
        date = [
            value.split('-')[2], 
            value.split('-')[1], 
            value.split('-')[0]
        ];

    switch(target) {
        case 'inputbx':
            return `${date[2]}-${digitize(date[0])}-${digitize(date[1])}`;
        case 'request':
            return `${digitize(date[0])}.${digitize(date[1])}.${date[2]}`;
        default:
            throw new Error('Unknown target to parse data for.');
    }
}
If you see the source of this repository under any circumstances, please, contact the owner of this repository through any public/private sources about it.

- <a href="mailto:io.falcion@outlook.com?subject=&body=">Outlook E-mail</a>

This repository IS NOT created for public share and represented temp, archive or private storage for codebases.

```md
Copyright conventions
(c) Falcion 2017-2024

Do not use, share under any circumstances until there is document stating otherwise.
```

#!/bin/bash

# Function to generate a random number between a given range
generate_random() {
  local min=$1
  local max=$2
  echo $((RANDOM % (max - min + 1) + min))
}

# Get the number of days
read -p "Enter the number of days: " days

# Check if the input is a valid number
if ! [[ "$days" =~ ^[0-9]+$ ]]; then
  echo "Error: Please enter a valid number."
  exit 1
fi

# Get the current date
current_date=$(date +%Y-%m-%d)

# Loop through each day and create an empty commit
for (( i=1; i<=$days; i++ )); do
  echo "Creating empty commit for $i days ago"
  num_commits=$(generate_random 1 5)  # Generate a random number of commits between 1 and 5
  for (( j=1; j<=$num_commits; j++ )); do
    git commit --allow-empty -m "*" --date "$i day ago"
  done
done

echo "Empty commits created successfully."

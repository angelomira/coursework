If you see this repository, there is something wrongs:\
everything here is shared on private terms of meaning.

> Falcion (c) 2017-2024